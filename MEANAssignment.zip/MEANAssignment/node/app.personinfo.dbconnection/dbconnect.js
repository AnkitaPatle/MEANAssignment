// var mongoose = require("mongoose");

// mongoose.Promise = global.Promise;

// mongoose.connect(
//     "mongodb://localhost/PersonInformation1",
//     { useNewUrlParser: true }
//   );
  
// var dbConnect = mongoose.connection;
//   if(!dbConnect) {
//     console.log("Connection is established");
//     return;
//   }