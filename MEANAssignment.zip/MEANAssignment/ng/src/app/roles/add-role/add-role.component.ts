import { Component, OnInit } from '@angular/core';

import { Role } from '../model/role.model';
@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.css']
})
export class AddRoleComponent implements OnInit {
  role: Role;
  roles: Array<Role>;
  constructor() {
    this.role = new Role(0, '');
   }

  ngOnInit() {

  }

}
