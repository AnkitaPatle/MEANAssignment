import { Component, OnInit } from '@angular/core';
import { Role } from './../model/role.model';
import { Roles } from './../model/role.model.data';
import { RoleLogic } from './../logic/role.logic';

@Component({
  selector: 'app-view-role',
  templateUrl: './view-role.component.html',
  styleUrls: ['./view-role.component.css']
})
export class ViewRoleComponent implements OnInit {
  role: Role;
  roles: Array<Role>;
  tableHeaders: Array<string>;
  tablerowcount: number;
  private logic: RoleLogic;
  checkAll: boolean;
  check: boolean;

  constructor() {
    this.role = new Role(0, '');
    this.roles = new Array<Role>();
    this.tableHeaders = new Array<string>();
    this.tablerowcount = 0;
  }

  ngOnInit(): void {
    // for (let r in this.roles) {
    //   this.tableHeaders.push(r);
    // }
    // for(let r in this.role){
    //   this.tableHeaders.push(r);
    // }
    // this.roles = this.logic.getRoles();
  }

  // clear(): void {
  //   this.role = new Role(0, '');
  // }
  // save(): void {
  //   this.roles = this.logic.saveRole(this.role);
  // }
  // getSelectedrow(r: Role): void {
  //   // 1.Create a deep copy of the selected product
  //   // 2.assign that copy to this.product
  //   this.role = Object.assign({}, r);
  // }
  // CheckAll(): void {
  //   if (this.checkAll === true) {
  //     this.checkAll = false;
  //     this.check = false;
  //   } else {
  //     this.checkAll = true;
  //     this.check = true;
  //   }
  // }
  // Check(): void {
  //   this.tablerowcount += 1;
  //   if (this.tablerowcount === this.roles.length) {
  //     this.checkAll = true;
  //   } else {
  //     this.checkAll = false;
  //   }
  // }
  // delete(): void {
  //   this.roles = this.logic.delete(this.roles.RoleID);
  // }
}
