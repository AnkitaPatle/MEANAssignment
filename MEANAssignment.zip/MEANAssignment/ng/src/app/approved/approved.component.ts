import { Component, OnInit } from '@angular/core';
import { Person, Persons } from './../../models/app.person.model';
import { FormGroup } from '@angular/forms';
import { PersonService } from 'src/services/PersonService';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

@Component({
  selector: 'app-approved',
  templateUrl: './approved.component.html',
  styleUrls: ['./approved.component.css']
})
export class ApprovedComponent implements OnInit {
  person: Person;
  token: string;
  persons: Array<Person>;
  personHeaders: Array<string>;
  personName: string;
  message: string;
  isUserListAvailable: boolean;

  constructor(private personServ: PersonService, private router: Router) {
    this.person = new Person(0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0);
    this.persons = new Array<Person>();
    this.personHeaders = new Array<string>('Person_ID', 'Person Name', 'Gender', 'Email', 'Mobile', );
    this.token = sessionStorage.getItem('token');
    this.personName = '';
    this.message = '';
    this.isUserListAvailable = true;
  }

  ngOnInit() {
      this.personServ.getApprovedPerson(this.token).subscribe(
        (resp: Response) => {
            this.persons = resp.json().data;
            console.log('JSON data' + JSON.stringify(this.persons));
            console.log('persons count :' + this.persons.length);
            // console.log(JSON.stringify('Email id :' + this.persons[0].email));
        },
        error => {
          console.log(`Error Occured ${JSON.stringify(error)}`);
        }
      );

      if (this.persons.length === 0 ) {
        this.isUserListAvailable = false;
      }
  }

}
