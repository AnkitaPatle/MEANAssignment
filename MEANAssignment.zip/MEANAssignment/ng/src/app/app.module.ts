// Inbuilt Components
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpModule } from '@angular/http';
// User Components
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserComponent } from './user/user.component';
import { PersonapprovalComponent } from './personapproval/personapproval.component';
import { PersonpendingComponent } from './personpending/personpending.component';
import { PersoninfoComponent } from './personinfo/personinfo.component';

// User Services
import { AppGuardService } from './../services/AppGuardService';
import { UserService } from './../services/UserService';
import { RoleService } from './../services/RoleService';
import { HomeComponent } from './home/home.component';
import { ListuserComponent } from './listuser/listuser.component';
import { AddRoleComponent } from './roles/add-role/add-role.component';
import { ViewRoleComponent } from './roles/view-role/view-role.component';
import { AddInfoComponent } from './add-info/add-info.component';
import { PersonService } from 'src/services/PersonService';
import { ApprovedComponent } from './approved/approved.component';
import { PendingComponent } from './pending/pending.component';
import { ProfileComponent } from './profile/profile.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    UserComponent,
    PersonapprovalComponent,
    PersonpendingComponent,
    PersoninfoComponent,
    HomeComponent,
    ListuserComponent,
    AddRoleComponent,
    ViewRoleComponent,
    AddInfoComponent,
    ApprovedComponent,
    PendingComponent,
    ProfileComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [AppGuardService, UserService, RoleService, PersonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
