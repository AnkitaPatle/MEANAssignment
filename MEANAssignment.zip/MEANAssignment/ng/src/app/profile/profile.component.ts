import { Component, OnInit } from '@angular/core';
import { UserService } from './../../services/UserService';
import { PersonService } from 'src/services/PersonService';
import { Person } from 'src/models/app.person.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Route } from '@angular/compiler/src/core';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from 'src/models/app.user.model';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: User;
  person: Person;
  token: string;
  persons: Array<Person>;
  personHeaders: Array<string>;
  personName: string;
  message: string;
  flag: string;
  roleName: string;
  userName: string;
  frmPerson: FormGroup;
  personService: PersonService;
  email: string;
  userId: number;

  constructor(
    private userServ: UserService,
    private personServ: PersonService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.user = new User('', '', '', 0);
    this.person = new Person(
      0,
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      0
    );
    this.persons = new Array<Person>();
    this.personHeaders = new Array<string>(
      'Person_ID',
      'Person Name',
      'Gender',
      'Email',
      'Mobile'
    );
    this.token = sessionStorage.getItem('token');
    this.personName = '';
    this.message = '';
    this.flag = '';
    this.roleName = '';

    this.userName = sessionStorage.getItem('userName');
    this.email = this.user.emailAddress;
    this.user = new User(this.userName, this.email, '', 0);
    this.person = new Person(
      0,
      this.userName,
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      this.email,
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      0
    );

    this.userServ
      .getUserDataByUserName(this.userName, sessionStorage.getItem('token'))
      .subscribe(resp => {
        this.user = resp.json().data;
        // this.token = sessionStorage.getItem('token');
        console.log('user data :-:' + JSON.stringify(this.user));
        // this.userName = (this.user)[0].userName;
        this.email = this.user[0].emailAddress;

        this.frmPerson = new FormGroup({
          personId: new FormControl(
            this.person.personId ? this.person.personId : null,
            Validators.compose([Validators.nullValidator, Validators.required])
          ),
          userName: new FormControl(
            this.person.userName ? this.person.userName : null,
            Validators.compose([Validators.nullValidator, Validators.required])
          ),
          firstName: new FormControl(
            this.person.firstName ? this.person.firstName : null,
            Validators.compose([
              Validators.nullValidator,
              Validators.required,
              Validators.pattern('[a-zA-Z]*')
            ])
          ),
          middleName: new FormControl(
            this.person.middleName ? this.person.middleName : null,
            Validators.compose([
              Validators.nullValidator,
              Validators.required,
              Validators.pattern('[a-zA-Z]*')
            ])
          ),
          lastName: new FormControl(
            this.person.lastName ? this.person.lastName : null,
            Validators.compose([
              Validators.nullValidator,
              Validators.required,
              Validators.pattern('[a-zA-Z]*')
            ])
          ),
          gender: new FormControl(
            this.person.gender ? this.person.gender : null,
            Validators.compose([Validators.nullValidator, Validators.required])
          ),
          dob: new FormControl(
            this.person.dob ? this.person.dob : null,
            Validators.compose([Validators.nullValidator, Validators.required])
          ),
          age: new FormControl(
            this.person.age ? this.person.age : null,
            Validators.compose([Validators.nullValidator, Validators.required])
          ),
          flatNumber: new FormControl(
            this.person.flatNumber ? this.person.flatNumber : null,
            Validators.compose([Validators.nullValidator, Validators.required])
          ),
          societyName: new FormControl(
            this.person.societyName ? this.person.societyName : null,
            Validators.compose([
              Validators.nullValidator,
              Validators.required,
              Validators.pattern('[a-zA-Z]*')
            ])
          ),
          areaName: new FormControl(
            this.person.areaName ? this.person.areaName : null,
            Validators.compose([Validators.nullValidator, Validators.required])
          ),
          email: new FormControl(
            this.person.email ? this.person.email : null,
            // (this.person.email = this.person.email || null),
            Validators.compose([
              Validators.required,
              Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$')
            ])
          ),
          city: new FormControl(
            this.person.city ? this.person.city : null,
            Validators.compose([
              Validators.nullValidator,
              Validators.required,
              Validators.pattern('[a-zA-Z]*')
            ])
          ),
          state: new FormControl(
            this.person.state ? this.person.state : null,
            Validators.compose([
              Validators.nullValidator,
              Validators.required,
              Validators.pattern('[a-zA-Z]*')
            ])
          ),
          pinCode: new FormControl(
            this.person.pinCode ? this.person.pinCode : null,
            Validators.compose([Validators.nullValidator, Validators.required])
          ),
          phoneNo: new FormControl(
            this.person.phoneNo ? this.person.phoneNo : null,
            Validators.compose([Validators.required])
          ),
          mobileNo: new FormControl(
            this.person.mobileNo ? this.person.mobileNo : null,
            Validators.compose([Validators.required])
          ),

          physicalDisability: new FormControl(
            this.person.physicalDisability
              ? this.person.physicalDisability
              : null,
            Validators.compose([Validators.required])
          ),

          maritalStatus: new FormControl(
            this.person.maritalStatus ? this.person.maritalStatus : null,
            Validators.compose([Validators.required])
          ),
          education: new FormControl(
            this.person.education ? this.person.education : null,
            Validators.compose([Validators.required])
          ),
          birthSign: new FormControl(
            this.person.birthSign ? this.person.birthSign : null,
            Validators.compose([Validators.required])
          ),
          isAuthorized: new FormControl(
            this.person.isAuthorized ? this.person.isAuthorized : null,
            Validators.compose([Validators.required])
          ),

          status: new FormControl(
            this.person.status ? this.person.status : null,
            Validators.compose([Validators.required])
          ),
          userId: new FormControl(
            this.person.userId ? this.person.userId : null,
            Validators.compose([Validators.required])
          )
        });
        this.person = new Person(0, this.userName, '', '',
          '', '', '', '', '', '', '', this.email, '', '', '', '',
          '', '', '', '', '', '', '' , 0);
        this.persons = new Array<Person>();
        this.token = sessionStorage.getItem('token');
        this.message = '';
        this.personServ
          .getPersonDataByEmail(this.email, sessionStorage.getItem('token'))
          .subscribe(
            // tslint:disable-next-line:no-shadowed-variable
            resp => {
              this.person = resp.json().data[0];
              this.frmPerson.setValue({
                personId: this.person.personId,
                userName: this.userName,
                firstName: this.person.firstName,
                middleName: this.person.middleName,
                lastName: this.person.lastName,
                gender: this.person.gender,
                dob: this.person.dob,
                age: this.person.age,
                flatNumber: this.person.flatNumber,
                societyName: this.person.societyName,
                areaName: this.person.areaName,
                email: this.person.email,
                city: this.person.city,
                state: this.person.state,
                pinCode: this.person.pinCode,
                phoneNo: this.person.phoneNo,
                mobileNo: this.person.mobileNo,
                physicalDisability: this.person.physicalDisability,
                maritalStatus: this.person.maritalStatus,
                education: this.person.education,
                birthSign: this.person.birthSign,
                isAuthorized:
                  sessionStorage.getItem('roleName') === 'Admin'
                    ? 'true'
                    : 'false',
                // this.person.isAuthorized,
                status: this.person.status,
                userId: this.person.userId
              });
              console.log(
                'this.frmPerson.value : ' + JSON.stringify(this.frmPerson.value)
              );
            },
            error => {
              console.log('errorrrrrrrrrrrrrrrrrrr');
              console.log(`Error occured ${error}`);
            }
          );
      });
  }

  ngOnInit() {}
}
