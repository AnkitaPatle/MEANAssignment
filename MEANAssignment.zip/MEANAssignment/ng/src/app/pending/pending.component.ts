import { Component, OnInit } from '@angular/core';
import { Person, Persons } from './../../models/app.person.model';
import { FormGroup } from '@angular/forms';
import { PersonService } from 'src/services/PersonService';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.css']
})
export class PendingComponent implements OnInit {
  person: Person;
  token: string;
  persons: Array<Person>;
  personHeaders: Array<string>;
  personName: string;
  message: string;
  flag: string;
  roleName: string;
  // isUserListAvailable: boolean;

  constructor(private personServ: PersonService, private router: Router) {
    this.person = new Person(0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0);
    this.persons = new Array<Person>();
    this.personHeaders = new Array<string>('Person_ID', 'Person Name', 'Gender', 'Email', 'Mobile', );
    this.token = sessionStorage.getItem('token');
    this.personName = '';
    this.message = '';
    this.flag = '';
    this.roleName = '';
    // this.isUserListAvailable = false;
  }

  ngOnInit() {


    this.roleName = sessionStorage.getItem('roleName');
    console.log(this.roleName);
    if (this.roleName === 'Admin') {
        this.flag = 'allGrant';
    } else if (this.roleName === 'Operator') {
        this.flag = 'noGrant';
    }

   // console.log('comes in ngOnInit');
    this.personServ.getPersonData(this.token).subscribe(
      (resp: Response) => {
          this.persons = resp.json().data;
          console.log(JSON.stringify(this.persons));
         // console.log(JSON.stringify('Email id :' + this.persons[0].email));
      },
      error => {
        console.log(`Error Occured ${JSON.stringify(error)}`);
      }
     );

    // if ( this.persons.length > 0) {
    //   this.isUserListAvailable = true;
    // }
  }

  approveUser(personToApprove: Person) {
    alert('clicked on approved -' + JSON.stringify(personToApprove));
    this.personServ.approvePerson(personToApprove, this.token).subscribe(
      (resp: Response) => {
       this.message = resp.json().message;
      },
      error => {
        console.log(`Error Occured ${error}`);
      }
    );
  }

  rejectUser(personId: number) {
    alert('clicked on reject -' + JSON.stringify(personId));
    this.personServ.rejectPerson(personId, this.token).subscribe(
      (resp: Response) => {
       this.message = resp.json().message;
      },
      error => {
        console.log(`Error Occured ${error}`);
      }
    );
  }

}
