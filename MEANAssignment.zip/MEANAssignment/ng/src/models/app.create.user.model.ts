
export class PersonInfo {
    constructor(
      public personId: number,
      public firstName: string,
      public middleName: string,
      public lastName: string,
      public gender: string,
      public dob: string,
      public age: number,
      public flatNumber: string,
      public societyName: string,
      public areaName: string,
      public email: string,
      public city: string,
      public state: string,
      public pinCode: number,
      public phoneNo: number,
      public mobileNo: number,
      public physicalDisability: string,
      public maritalStatus: string,
      public education: string,
      public birthSign: string
    ){}

}
