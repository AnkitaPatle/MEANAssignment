import { Injectable } from "@angular/core";
import { Http, Response, Headers, RequestOptions } from "@angular/http";
import { Observable } from "rxjs";
import { Person } from "./../models/app.person.model";
// import { request } from "http";

@Injectable()
export class PersonService {
  url: string;
  constructor(private http: Http) {
    this.url = "http://localhost:4040";
  }

  getLoginInfo(person: Person): Observable<Response> {
    let resp: Observable<Response>;

    const header: Headers = new Headers({
      "Content-Type": "application/json"
    });

    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.post(
      `${this.url}/api/users/auth`,
      JSON.stringify(person),
      options
    );
    return resp;
  }

  getPersonData(token: string): Observable<Response> {
    let resp: Observable<Response>;
    const header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });

    const options: RequestOptions = new RequestOptions();
    options.headers = header;
    resp = this.http.get(`${this.url}/api/personinfo`, options);

    return resp;
  }

  getApprovedPerson(token: string): Observable<Response> {
    console.log("In service :");
    let resp: Observable<Response>;
    const header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });

    console.log("Going to hit API");
    const options: RequestOptions = new RequestOptions();
    options.headers = header;
    resp = this.http.get(`${this.url}/api/personinfoForApprove`, options);
    console.log("resp :" + resp);

    return resp;
  }

  getPersonDataByUserName(
    userName: string,
    token: string
  ): Observable<Response> {
    let resp: Observable<Response>;
    console.log("In getPersonDataByUserName :" + userName);
    const header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token,
      userName: userName
    });
    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.get(`${this.url}/api/user`, options);

    return resp;
  }

  getPersonDataByEmail(email: string, token: string): Observable<Response> {
    let resp: Observable<Response>;
    console.log("In getPersonDataByEmail :" + email);
    const header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token,
      email: email
    });
    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    console.log("req headers" + JSON.stringify(header));
    console.log("going to hit api/person/email");
    resp = this.http.get(`${this.url}/api/person/email`, options);
    console.log(" resp : " + JSON.stringify(resp));
    return resp;
  }

  postPersonData(person: Person, token: string): Observable<Response> {
    let resp: Observable<Response>;

    console.log("Person data in service call" + JSON.stringify(person));

    const header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });

    const options: RequestOptions = new RequestOptions();
    options.headers = header;
    console.log("going to hit /api/personinfo");
    resp = this.http.post(
      `${this.url}/api/personinfo`,
      JSON.stringify(person),
      options
    );
    return resp;
  }

  approvePerson(person: Person, token: string): Observable<Response> {
    let resp: Observable<Response>;

    console.log(JSON.stringify(person));

    const header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
    });
    console.log(
      " Approve Person data in service , going to hit APi: " +
        JSON.stringify(person)
    );
    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.post(
      `${this.url}/api/personinfoapprove/`,
      JSON.stringify(person),
      options
    );
    return resp;
  }

  rejectPerson(personId: number, token: string): Observable<Response> {
    let resp: Observable<Response>;

    console.log(JSON.stringify(personId));

    const header: Headers = new Headers({
      "Content-Type": "application/json",
      authorization: "bearer " + token
      // ,
      // 'personId': personId
    });
    console.log(
      "going to hit /api/tempPersoninfoReject  for personId:" + personId
    );
    const options: RequestOptions = new RequestOptions();
    options.headers = header;

    resp = this.http.delete(
      `${this.url}/api/tempPersoninfoReject/` + personId,
      options
    );
    return resp;
  }
}
